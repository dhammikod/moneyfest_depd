<?php

namespace App\Http\Controllers;

use App\Models\Jenis_Kategori;
use App\Http\Requests\StoreJenis_KategoriRequest;
use App\Http\Requests\UpdateJenis_KategoriRequest;

class JenisKategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreJenis_KategoriRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Jenis_Kategori $jenis_Kategori)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Jenis_Kategori $jenis_Kategori)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateJenis_KategoriRequest $request, Jenis_Kategori $jenis_Kategori)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Jenis_Kategori $jenis_Kategori)
    {
        //
    }
}
