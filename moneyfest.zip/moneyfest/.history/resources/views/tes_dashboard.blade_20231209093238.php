{{$transactions}}

@foreach ($kategori as $item)
    {{$item}}
@endforeach
